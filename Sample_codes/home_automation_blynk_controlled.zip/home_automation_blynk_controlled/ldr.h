#ifndef LDR_H
#define LDR_H


#define LDR_SENSOR       A1
#define GARDEN_LIGHT     6



void init_ldr(void);
void brightness_control(void);

#endif
