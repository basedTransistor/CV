#ifndef MAIN_H
#define MAIN_H


#define ON    1
#define OFF   0

#define TEMPERATURE_GAUGE       V1
#define COOLER_V_PIN            V0
#define HEATER_V_PIN            V2
#define WATER_VOL_GAUGE         V3
#define INLET_V_PIN             V4
#define OUTLET_V_PIN            V5
#define BLYNK_TEMP_TERMINAL_V_PIN    V6
#define BLYNK_TANK_TERMINAL_V_PIN    V7


#endif
